package com.example.demo.exception;

public class WeatherTrackerException extends RuntimeException {
    public WeatherTrackerException(String message) {
        super(message);
    }
}
