package com.example.demo.external.opencega.model;

public class Geometry {
    private double lat;
    private double lng;

    public double getLat() {
        return lat;
    }

    public double setLat(double lat) {
        return this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public double setLng(double lng) {
        return this.lng = lng;
    }

}
