package com.example.demo.service;

import com.example.demo.dto.UserDetailDto;

import java.util.List;

public interface UserDetailService {
    List<UserDetailDto> getAll();
}
