package com.example.demo.dto;

public class OpenWeatherDto {
    private String description;
    private double temperature;
    private double feelsLike;
    private int humidity;
    private double windSpeed;
}
