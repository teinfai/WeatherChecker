package com.example.demo.external.opencega.model;

//public class Result {
//    private Geometry geometry;
//
//    public Geometry getGeometry() {
//        return geometry;
//    }
//
//    public void setGeometry(Geometry geometry) {
//        this.geometry = geometry;
//    }
//}

public class Result {
    private Geometry geometry;

    public Geometry getGeometry() {
        return geometry;
    }

    public Geometry setGeometry(Geometry geometry) {
        return this.geometry = geometry;
    }
}
